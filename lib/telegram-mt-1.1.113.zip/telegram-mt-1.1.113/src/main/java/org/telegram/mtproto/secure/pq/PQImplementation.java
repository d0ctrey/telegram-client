package org.telegram.mtproto.secure.pq;

/**
 * Created by ex3ndr on 12.02.14.
 */
public interface PQImplementation {
    public long findDivider(long src);
}
