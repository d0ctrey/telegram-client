package org.telegram.mtproto.tl.pq;

import org.telegram.tl.TLObject;

/**
 * Created with IntelliJ IDEA.
 * User: ex3ndr
 * Date: 03.11.13
 * Time: 6:27
 */
public abstract class ServerDhParams extends TLObject {
}
