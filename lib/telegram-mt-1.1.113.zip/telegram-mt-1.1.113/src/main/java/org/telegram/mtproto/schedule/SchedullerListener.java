package org.telegram.mtproto.schedule;

/**
 * Created by ex3ndr on 03.04.14.
 */
public interface SchedullerListener {
    public void onSchedullerUpdated(Scheduller scheduller);
}
